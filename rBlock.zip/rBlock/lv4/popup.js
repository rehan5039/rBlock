let isBlocking = true;

// Update the toggle button and status text based on blocking state
function updateStatus() {
    document.getElementById('status').innerText = isBlocking ? 'Enabled' : 'Disabled';
    document.getElementById('toggle').innerText = isBlocking ? 'Disable Blocking' : 'Enable Blocking';
}

// Load the initial blocking state and update the UI accordingly
chrome.storage.sync.get('isBlocking', (data) => {
    isBlocking = data.isBlocking !== undefined ? data.isBlocking : true; // Default to enabled
    updateStatus();
});

// Toggle blocking state
function toggleBlocking() {
    isBlocking = !isBlocking;
    chrome.runtime.sendMessage({ action: 'toggleBlocking', isBlocking }, (response) => {
        if (response.success) {
            updateStatus();
            console.log(`Blocking is now ${isBlocking ? 'enabled' : 'disabled'}.`);
        }
    });
}

// Event listener for the toggle button
document.getElementById('toggle').addEventListener('click', toggleBlocking);

// Update blocked ad count in real-time
function updateBlockedCount() {
    chrome.declarativeNetRequest.getDynamicRules((rules) => {
        const blockedCount = rules.length; // Approximation of blocked rules count
        document.getElementById('adsBlocked').innerText = blockedCount;
    });
}

// Continuously listen for changes in the blocked count and update UI
chrome.storage.onChanged.addListener((changes) => {
    if (changes.adsBlocked) {
        updateBlockedCount();
    }
});
