// generate-manifest.js
import { trackerUrls } from './urls.js';
import fs from 'fs';

const manifest = {
    manifest_version: 3,
    name: "rBlock",
    version: "3.0",
    description: "Ads and tracker blocker",
    permissions: [
        "declarativeNetRequest",
        "storage"
    ],
    host_permissions: trackerUrls, // Inject URLs here
    background: {
        service_worker: "background.js"
    },
    action: {
        default_popup: "popup.html",
        default_icon: {
            "16": "icons/16x16.png",
            "48": "icons/48x48.png",
            "128": "icons/128x128.png"
        }
    },
    icons: {
        "16": "icons/16x16.png",
        "48": "icons/48x48.png",
        "128": "icons/128x128.png"
    }
};

// Write the generated manifest to manifest.json
fs.writeFileSync('manifest.json', JSON.stringify(manifest, null, 2));
console.log("manifest.json has been generated with tracker URLs.");
