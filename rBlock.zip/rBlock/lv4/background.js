// background.js
import { trackerUrls } from './urls.js';

// Convert URLs to declarativeNetRequest rule format
const rules = trackerUrls.map((url, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "block" },
    condition: { urlFilter: url }
}));

// Enable blocking rules on install and startup
function enableBlocking() {
    chrome.declarativeNetRequest.updateDynamicRules({
        addRules: rules,
        removeRuleIds: rules.map(rule => rule.id)
    }, () => {
        console.log("Blocking rules enabled.");
    });
}

// Remove blocking rules
function disableBlocking() {
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: rules.map(rule => rule.id)
    }, () => {
        console.log("Blocking rules disabled.");
    });
}

// Initial setup: enable blocking by default
chrome.runtime.onInstalled.addListener(() => {
    enableBlocking();
    chrome.storage.sync.set({ isBlocking: true });
});

// Handle toggle requests from popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        if (request.isBlocking) {
            enableBlocking();
        } else {
            disableBlocking();
        }
        chrome.storage.sync.set({ isBlocking: request.isBlocking });
        sendResponse({ success: true });
    }
});
