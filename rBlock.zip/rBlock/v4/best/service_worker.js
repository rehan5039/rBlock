// Listen for installation and apply blocking rules
chrome.runtime.onInstalled.addListener(() => {
    console.log("Ad blocker installed.");

    // Set the default blocking state to enabled
    chrome.storage.sync.set({ isBlocking: true }, () => {
        enableBlockingRules();
    });
});

// Listen for startup events (when browser starts)
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.sync.get('isBlocking', (data) => {
        if (data.isBlocking) {
            enableBlockingRules();
        }
    });
});

// Message listener for toggling ad-blocking from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        toggleBlocking(sendResponse);
    }
    return true; // Keep the message channel open
});

// Function to toggle ad blocking rules on or off
function toggleBlocking(sendResponse) {
    chrome.storage.sync.get('isBlocking', (data) => {
        const isBlocking = !data.isBlocking;
        chrome.storage.sync.set({ isBlocking }, () => {
            if (isBlocking) {
                enableBlockingRules();
            } else {
                clearBlockingRules();
            }
            sendResponse({ success: true, isBlocking });
        });
    });
}

// Function to enable ad-blocking rules
function enableBlockingRules() {
    const rules = [
        // Blocking various ad types based on URL patterns
        {
            id: 1,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.doubleclick.net/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 2,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.googlesyndication.com/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 3,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsense.google.com/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 4,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsterra.com/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 5,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.media.net/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 6,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adf.ly/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 7,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popads.net/*", resourceTypes: ["script", "image", "xmlhttprequest", "media"] }
        },
        {
            id: 8,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.banner.468x60/*", resourceTypes: ["image", "media", "sub_frame"] }
        },
        {
            id: 9,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.banner.300x250/*", resourceTypes: ["image", "media", "sub_frame"] }
        },
        {
            id: 10,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.banner.320x50/*", resourceTypes: ["image", "media", "sub_frame"] }
        },
        {
            id: 11,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.video.ads/*", resourceTypes: ["media", "xmlhttprequest"] }
        }
        // Add more URL patterns as needed
    ];

    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [],  // Keep current rules
        addRules: rules
    }, () => {
        console.log("Ad-blocking rules applied.");
    });
}

// Function to clear blocking rules
function clearBlockingRules() {
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
        addRules: []
    }, () => {
        console.log("Ad-blocking rules cleared.");
    });
}
