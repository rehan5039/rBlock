// Load host permissions URLs from host_permissions.json
async function getTrackerUrls() {
    const response = await fetch(chrome.runtime.getURL('host_permissions.json'));
    const data = await response.json();
    return data.host_permissions;
}

// Function to hide ads instead of blocking them outright
function hideAds() {
    const hideAdCSS = `
        /* Hide common ad elements using CSS */
        [id*='ad'], [class*='ad'], [id*='banner'], [class*='banner'], 
        [id*='sponsored'], [class*='sponsored'] {
            display: none !important;
        }

        /* Hide common popups and overlays */
        [id*='popup'], [class*='popup'], 
        [id*='overlay'], [class*='overlay'] {
            visibility: hidden !important;
            opacity: 0 !important;
        }
    `;

    // Inject CSS into every webpage
    const styleElement = document.createElement('style');
    styleElement.innerText = hideAdCSS;
    document.head.appendChild(styleElement);
}

// Function to redirect ad and tracking requests to blank response
function redirectAdsAndTrackers() {
    const redirectRules = [
        {
            id: 1,
            priority: 1,
            action: {
                type: "redirect",
                redirect: {
                    url: "data:text/plain,",
                }
            },
            condition: {
                urlFilter: "*://*.adserver.com/*",
                resourceTypes: ["image", "script", "xmlhttprequest"]
            }
        },
        {
            id: 2,
            priority: 1,
            action: {
                type: "redirect",
                redirect: {
                    url: "data:text/plain,",
                }
            },
            condition: {
                urlFilter: "*://*.tracking.com/*",
                resourceTypes: ["image", "script", "xmlhttprequest"]
            }
        },
        {
            id: 3,
            priority: 1,
            action: {
                type: "redirect",
                redirect: {
                    url: "data:text/plain,",
                }
            },
            condition: {
                urlFilter: "*://*.doubleclick.net/*",
                resourceTypes: ["image", "script", "xmlhttprequest"]
            }
        },
        // Add more rules for other ad/tracking URLs
    ];

    // Update dynamic rules: remove existing and add new ones
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: Array.from({ length: redirectRules.length }, (_, i) => i + 1),
        addRules: redirectRules
    }, () => {
        console.log("Ad and tracking requests are redirected to a blank response.");
    });
}

// Prevent websites from detecting ad blockers via DOM modifications
function preventAdBlockDetection() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'childList' || mutation.type === 'attributes') {
                // Remove elements that detect adblockers
                if (mutation.target.matches('[id*="adblock"], [class*="adblock"]')) {
                    mutation.target.remove();
                }
            }
        });
    });

    observer.observe(document, {
        childList: true,
        attributes: true,
        subtree: true
    });
}

// Randomize the user agent to avoid detection
chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
        const userAgents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Linux; Android 10; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36",
            // Add more user agents if needed
        ];

        details.requestHeaders["User-Agent"] = userAgents[Math.floor(Math.random() * userAgents.length)];
        return { requestHeaders: details.requestHeaders };
    },
    { urls: ["<all_urls>"] },
    ["blocking", "requestHeaders"]
);

// Setup blocking rules and hide ads
async function setupBlocking() {
    const trackerUrls = await getTrackerUrls();

    // Use CSS to hide ads dynamically instead of blocking
    chrome.webNavigation.onCompleted.addListener(() => {
        chrome.scripting.executeScript({
            target: { allFrames: true },
            func: hideAds
        });
    }, { url: [{ urlMatches: 'http://*/*' }, { urlMatches: 'https://*/*' }] });

    // Redirect ad and tracker requests
    redirectAdsAndTrackers();

    // Prevent ad blocker detection via DOM
    chrome.webNavigation.onCompleted.addListener(() => {
        chrome.scripting.executeScript({
            target: { allFrames: true },
            func: preventAdBlockDetection
        });
    }, { url: [{ urlMatches: 'http://*/*' }, { urlMatches: 'https://*/*' }] });
}

// Initialize blocking when the extension is installed or activated
chrome.runtime.onInstalled.addListener(() => {
    setupBlocking();
    chrome.storage.sync.set({ isBlocking: true }); // Default to enabled
});

chrome.runtime.onStartup.addListener(() => {
    setupBlocking(); // Re-apply blocking on browser startup
});

// Toggle ad blocking on user request
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        chrome.storage.sync.get('isBlocking', (data) => {
            const isBlocking = !data.isBlocking;
            chrome.storage.sync.set({ isBlocking }, () => {
                if (isBlocking) {
                    setupBlocking();
                    console.log("Ad blocking enabled.");
                } else {
                    chrome.declarativeNetRequest.updateDynamicRules({
                        removeRuleIds: Array.from({ length: 100 }, (_, i) => i + 1) // Remove all blocking rules
                    }, () => {
                        console.log("Ad blocking disabled.");
                    });
                }
                sendResponse({ success: true });
            });
        });
    }
    return true; // Keep the message channel open for sendResponse
});
