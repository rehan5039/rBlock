// Function to block ads by size and common ad-related classes
function blockAdsBySize() {
    const adSizes = [
        { width: 468, height: 60 },
        { width: 300, height: 250 },
        { width: 320, height: 50 },
        { width: 160, height: 300 },
        { width: 160, height: 600 },
        { width: 728, height: 90 }
    ];

    // Query all iframe and div elements (commonly used for ads)
    const elements = document.querySelectorAll('iframe, div, img');

    elements.forEach(element => {
        const rect = element.getBoundingClientRect();
        
        // Check if element matches any known ad sizes
        adSizes.forEach(size => {
            if (rect.width === size.width && rect.height === size.height) {
                element.style.display = 'none'; // Hide the ad
                console.log(`Blocked ad with size: ${size.width}x${size.height}`);
            }
        });

        // Additional checks for common ad classes or IDs (optional)
        if (element.id.includes('ad') || element.className.includes('ad')) {
            element.style.display = 'none'; // Hide the element if it's an ad
            console.log(`Blocked ad based on ID or class: ${element.id || element.className}`);
        }
    });
}

// Run the ad-blocking function
blockAdsBySize();

// Optionally, run the function periodically to catch dynamically loaded ads
setInterval(blockAdsBySize, 5000);
