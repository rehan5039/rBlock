// Load host permissions URLs from host_permissions.json
async function getTrackerUrls() {
    const response = await fetch(chrome.runtime.getURL('host_permissions.json'));
    const data = await response.json();
    return data.host_permissions;
}

// Helper function to create block rules
function createBlockRules(urls, startId) {
    return urls.map((url, index) => ({
        id: startId + index,
        priority: 1,
        action: { type: "block" },
        condition: { urlFilter: url }
    }));
}

// Convert URLs to rules and enable blocking
async function setupBlockingRules() {
    const trackerUrls = await getTrackerUrls();

    // Initial blocking rules
    const rules = createBlockRules(trackerUrls, 1);

    // Additional rules for various ad types, pop-ups, and unwanted redirections
    const additionalBlockRules = [
        // Banner Ads

        {
            id: trackerUrls.length + 1,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popads.net/*" }
        },
        {
            id: trackerUrls.length + 2,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsterra.com/*" }
        },
        {
            id: trackerUrls.length + 3,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.doubleclick.net/*" }
        },
        {
            id: trackerUrls.length + 4,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popunder.net/*" }
        },
        {
            id: trackerUrls.length + 5,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ads.com/*" }
        },

        {
            id: trackerUrls.length + 6,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adf.ly/*" }
        },
        {
            id: trackerUrls.length + 7,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.linkbucks.com/*" }
        },
        {
            id: trackerUrls.length + 8,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adclick.g.doubleclick.net/*" }
        },
        {
            id: trackerUrls.length + 9,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.getpopups.com/*" }
        },
        {
            id: trackerUrls.length + 10,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adserver.adtech.de/*" }
        },
        {
            id: trackerUrls.length + 11,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trafficjunky.net/*" }
        },
        {
            id: trackerUrls.length + 12,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.advertising.com/*" }
        },
        {
            id: trackerUrls.length + 13,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ads.yahoo.com/*" }
        },
        {
            id: trackerUrls.length + 14,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ezoic.net/*" }
        },
        {
            id: trackerUrls.length + 15,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.propellerads.com/*" }
        },
        {
            id: trackerUrls.length + 16,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adfoc.us/*" }
        },
        {
            id: trackerUrls.length + 17,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fastclick.net/*" }
        },
        {
            id: trackerUrls.length + 18,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.sponsorads.com/*" }
        },
        {
            id: trackerUrls.length + 19,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.paypopup.com/*" }
        },
        {
            id: trackerUrls.length + 20,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.t3.gstatic.com/*" }
        },
        {
            id: trackerUrls.length + 21,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.tracking202.com/*" }
        },
        {
            id: trackerUrls.length + 22,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adMaven.com/*" }
        },
        {
            id: trackerUrls.length + 23,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.gohighbrow.com/*" }
        },
        {
            id: trackerUrls.length + 24,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bannersnack.com/*" }
        },
        {
            id: trackerUrls.length + 25,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.myadcenter.com/*" }
        },
        {
            id: trackerUrls.length + 26,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adservice.google.com/*" }
        },
        {
            id: trackerUrls.length + 27,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.kaspersky.com/*" }
        },
        {
            id: trackerUrls.length + 28,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popupwindow.com/*" }
        },
        {
            id: trackerUrls.length + 29,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.zvukav.com/*" }
        },
        {
            id: trackerUrls.length + 30,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adx.com/*" }
        },

        {
            id: trackerUrls.length + 31,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popads.net/*" }
        },
        {
            id: trackerUrls.length + 32,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsterra.com/*" }
        },
        {
            id: trackerUrls.length + 33,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.doubleclick.net/*" }
        },
        {
            id: trackerUrls.length + 34,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popunder.net/*" }
        },
        {
            id: trackerUrls.length + 35,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ads.com/*" }
        },
        {
            id: trackerUrls.length + 36,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.cpmstar.com/*" }
        },
        {
            id: trackerUrls.length + 37,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adnetwork.com/*" }
        },
        {
            id: trackerUrls.length + 38,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsymphony.com/*" }
        },
        {
            id: trackerUrls.length + 39,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adinfuse.com/*" }
        },
        {
            id: trackerUrls.length + 40,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.clicksor.com/*" }
        },
        {
            id: trackerUrls.length + 41,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.cpmadvertising.com/*" }
        },
        {
            id: trackerUrls.length + 42,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adblade.com/*" }
        },
        {
            id: trackerUrls.length + 43,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popmyads.com/*" }
        },
        {
            id: trackerUrls.length + 44,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.hpg.in/*" }
        },
        {
            id: trackerUrls.length + 45,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popunder.us/*" }
        },
        {
            id: trackerUrls.length + 46,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.wowpopup.com/*" }
        },
        {
            id: trackerUrls.length + 47,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fuq.com/*" }
        },
        {
            id: trackerUrls.length + 48,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popcorn.com/*" }
        },
        {
            id: trackerUrls.length + 49,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.getfreeaccess.com/*" }
        },
        {
            id: trackerUrls.length + 50,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.genieads.com/*" }
        },
        {
            id: trackerUrls.length + 51,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adkit.com/*" }
        },
        {
            id: trackerUrls.length + 52,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.unbounce.com/*" }
        },
        {
            id: trackerUrls.length + 53,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.freshpopups.com/*" }
        },
        {
            id: trackerUrls.length + 54,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adscendmedia.com/*" }
        },
        {
            id: trackerUrls.length + 55,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bit.ly/*" }
        },
        {
            id: trackerUrls.length + 56,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.tinyurl.com/*" }
        },
        {
            id: trackerUrls.length + 57,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.shorte.st/*" }
        },
        {
            id: trackerUrls.length + 58,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adopted.com/*" }
        },
        {
            id: trackerUrls.length + 59,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.1clickadvertising.com/*" }
        },
        {
            id: trackerUrls.length + 60,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adfund.com/*" }
        },
        {
            id: trackerUrls.length + 61,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.dynamicads.com/*" }
        },
        {
            id: trackerUrls.length + 62,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsrvmedia.com/*" }
        },
        {
            id: trackerUrls.length + 63,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.clickadu.com/*" }
        },
        {
            id: trackerUrls.length + 64,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.onead.com/*" }
        },
        {
            id: trackerUrls.length + 65,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.blitzads.com/*" }
        },
        {
            id: trackerUrls.length + 66,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.leadbolt.com/*" }
        },
        {
            id: trackerUrls.length + 67,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popunder.com/*" }
        },
        {
            id: trackerUrls.length + 68,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adfurnace.com/*" }
        },
        {
            id: trackerUrls.length + 69,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.zzads.com/*" }
        },
        {
            id: trackerUrls.length + 70,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.exitjunction.com/*" }
        },
        {
            id: trackerUrls.length + 71,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.admantx.com/*" }
        },
        {
            id: trackerUrls.length + 72,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.floodlight.net/*" }
        },
        {
            id: trackerUrls.length + 73,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ad-empire.com/*" }
        },
        {
            id: trackerUrls.length + 74,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adring.com/*" }
        },
        {
            id: trackerUrls.length + 75,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.overture.com/*" }
        },
        {
            id: trackerUrls.length + 76,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.buzzon.com/*" }
        },
        {
            id: trackerUrls.length + 77,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.tracking-protection.com/*" }
        },
        {
            id: trackerUrls.length + 78,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.zoolz.com/*" }
        },
        {
            id: trackerUrls.length + 79,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trackzilla.com/*" }
        },
        {
            id: trackerUrls.length + 80,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adscript.net/*" }
        },
        {
            id: trackerUrls.length + 81,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bidsystem.com/*" }
        },
        {
            id: trackerUrls.length + 82,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adserverplus.com/*" }
        },
        {
            id: trackerUrls.length + 83,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.mclick.com/*" }
        },
        {
            id: trackerUrls.length + 84,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.goodad.com/*" }
        },
        {
            id: trackerUrls.length + 85,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.hitbaits.com/*" }
        },
        {
            id: trackerUrls.length + 86,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adbooth.com/*" }
        },
        {
            id: trackerUrls.length + 87,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.discreetads.com/*" }
        },
        {
            id: trackerUrls.length + 88,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.wallethub.com/*" }
        },
        {
            id: trackerUrls.length + 89,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adline.com/*" }
        },
        {
            id: trackerUrls.length + 90,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.suspendedads.com/*" }
        },
        {
            id: trackerUrls.length + 91,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.prospectads.com/*" }
        },
        {
            id: trackerUrls.length + 92,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popup-cam.com/*" }
        },
        {
            id: trackerUrls.length + 93,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nichead.com/*" }
        },
        {
            id: trackerUrls.length + 94,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.infinityads.com/*" }
        },
        {
            id: trackerUrls.length + 95,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.easyadvertising.com/*" }
        },
        {
            id: trackerUrls.length + 96,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.youradspace.com/*" }
        },
        {
            id: trackerUrls.length + 97,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.xaxxx.com/*" }
        },
        {
            id: trackerUrls.length + 98,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.revenuehits.com/*" }
        },
        {
            id: trackerUrls.length + 99,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.sillyads.com/*" }
        },
        {
            id: trackerUrls.length + 100,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popdeals.com/*" }
        },
        {
            id: trackerUrls.length + 101,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.offervault.com/*" }
        },
        {
            id: trackerUrls.length + 102,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adforever.com/*" }
        },
        {
            id: trackerUrls.length + 103,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.topadvert.com/*" }
        },
        {
            id: trackerUrls.length + 104,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adfreebies.com/*" }
        },
        {
            id: trackerUrls.length + 105,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.helpinghandads.com/*" }
        },
        {
            id: trackerUrls.length + 106,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.sharemyads.com/*" }
        },
        {
            id: trackerUrls.length + 107,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.safeads.com/*" }
        },
        {
            id: trackerUrls.length + 108,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.hybridads.com/*" }
        },
        {
            id: trackerUrls.length + 109,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bunnyads.com/*" }
        },
        {
            id: trackerUrls.length + 110,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ad2click.com/*" }
        },
        {
            id: trackerUrls.length + 111,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adfury.com/*" }
        },
        {
            id: trackerUrls.length + 112,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.webads.com/*" }
        },
        {
            id: trackerUrls.length + 113,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pocketads.com/*" }
        },
        {
            id: trackerUrls.length + 114,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.crazyads.com/*" }
        },
        {
            id: trackerUrls.length + 115,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.easyclick.com/*" }
        },
        {
            id: trackerUrls.length + 116,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsober.com/*" }
        },
        {
            id: trackerUrls.length + 117,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.moneycart.com/*" }
        },
        {
            id: trackerUrls.length + 118,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.dynamiccreative.com/*" }
        },
        {
            id: trackerUrls.length + 119,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.thedirectad.com/*" }
        },
        {
            id: trackerUrls.length + 120,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inviteme.com/*" }
        },
        {
            id: trackerUrls.length + 121,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.guestads.com/*" }
        },
        {
            id: trackerUrls.length + 122,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.yielder.com/*" }
        },
        {
            id: trackerUrls.length + 123,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.spotad.com/*" }
        },
        {
            id: trackerUrls.length + 124,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.evergreenads.com/*" }
        },
        {
            id: trackerUrls.length + 125,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.slyads.com/*" }
        },
        {
            id: trackerUrls.length + 126,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.classicad.com/*" }
        },
        {
            id: trackerUrls.length + 127,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.stableads.com/*" }
        },
        {
            id: trackerUrls.length + 128,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.keepsakeads.com/*" }
        },
        {
            id: trackerUrls.length + 129,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nativeads.com/*" }
        },
        {
            id: trackerUrls.length + 130,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.advertmarket.com/*" }
        },
        {
            id: trackerUrls.length + 131,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popstatus.com/*" }
        },
        {
            id: trackerUrls.length + 132,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popout.com/*" }
        },
        {
            id: trackerUrls.length + 133,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.webtrafficads.com/*" }
        },
        {
            id: trackerUrls.length + 134,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.merchads.com/*" }
        },
        {
            id: trackerUrls.length + 135,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.allureads.com/*" }
        },
        {
            id: trackerUrls.length + 136,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.auraads.com/*" }
        },
        {
            id: trackerUrls.length + 137,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adwave.com/*" }
        },
        {
            id: trackerUrls.length + 138,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pulseads.com/*" }
        },
        {
            id: trackerUrls.length + 139,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inboxads.com/*" }
        },
        {
            id: trackerUrls.length + 140,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.foxyads.com/*" }
        },
        {
            id: trackerUrls.length + 141,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.sizzleads.com/*" }
        },
        {
            id: trackerUrls.length + 142,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.earnyourads.com/*" }
        },
        {
            id: trackerUrls.length + 143,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trendyads.com/*" }
        },
        {
            id: trackerUrls.length + 144,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.novelads.com/*" }
        },
        {
            id: trackerUrls.length + 145,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.mightyads.com/*" }
        },
        {
            id: trackerUrls.length + 146,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.kingads.com/*" }
        },
        {
            id: trackerUrls.length + 147,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.hiddenads.com/*" }
        },
        {
            id: trackerUrls.length + 148,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.vortexads.com/*" }
        },
        {
            id: trackerUrls.length + 149,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.plushads.com/*" }
        },
        {
            id: trackerUrls.length + 150,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.midnightads.com/*" }
        },
        {
            id: trackerUrls.length + 151,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.stellarads.com/*" }
        },
        {
            id: trackerUrls.length + 152,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nuageads.com/*" }
        },
        {
            id: trackerUrls.length + 153,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.screenshotads.com/*" }
        },
        {
            id: trackerUrls.length + 154,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fancyads.com/*" }
        },
        {
            id: trackerUrls.length + 155,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.advantageads.com/*" }
        },
        {
            id: trackerUrls.length + 156,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.dreamads.com/*" }
        },
        {
            id: trackerUrls.length + 157,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.guerrillaads.com/*" }
        },
        {
            id: trackerUrls.length + 158,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inspiredads.com/*" }
        },
        {
            id: trackerUrls.length + 159,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.promoteads.com/*" }
        },
        {
            id: trackerUrls.length + 160,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.maxxads.com/*" }
        },
        {
            id: trackerUrls.length + 161,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.notads.com/*" }
        },
        {
            id: trackerUrls.length + 162,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.doublepay.com/*" }
        },
        {
            id: trackerUrls.length + 163,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bounceads.com/*" }
        },
        {
            id: trackerUrls.length + 164,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.directads.com/*" }
        },
        {
            id: trackerUrls.length + 165,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.streetadvert.com/*" }
        },
        {
            id: trackerUrls.length + 166,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nextgenads.com/*" }
        },
        {
            id: trackerUrls.length + 167,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adrenalin.com/*" }
        },
        {
            id: trackerUrls.length + 168,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.boostedads.com/*" }
        },
        {
            id: trackerUrls.length + 169,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fasttrackads.com/*" }
        },
        {
            id: trackerUrls.length + 170,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.infiniteads.com/*" }
        },
        {
            id: trackerUrls.length + 171,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.portalads.com/*" }
        },
        {
            id: trackerUrls.length + 172,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adsensesolutions.com/*" }
        },
        {
            id: trackerUrls.length + 173,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.shamelessads.com/*" }
        },
        {
            id: trackerUrls.length + 174,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trickyads.com/*" }
        },
        {
            id: trackerUrls.length + 175,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.uniqueads.com/*" }
        },
        {
            id: trackerUrls.length + 176,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.unlimitedads.com/*" }
        },
        {
            id: trackerUrls.length + 177,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nextlevelads.com/*" }
        },
        {
            id: trackerUrls.length + 178,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.admiral.com/*" }
        },
        {
            id: trackerUrls.length + 179,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.brandadvertising.com/*" }
        },
        {
            id: trackerUrls.length + 180,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.hyperads.com/*" }
        },
        {
            id: trackerUrls.length + 181,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adspace.com/*" }
        },
        {
            id: trackerUrls.length + 182,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.theadcompany.com/*" }
        },
        {
            id: trackerUrls.length + 183,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.creativeads.com/*" }
        },
        {
            id: trackerUrls.length + 184,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.classicads.com/*" }
        },
        {
            id: trackerUrls.length + 185,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.instinctads.com/*" }
        },
        {
            id: trackerUrls.length + 186,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.popupssuck.com/*" }
        },
        {
            id: trackerUrls.length + 187,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.screamingads.com/*" }
        },
        {
            id: trackerUrls.length + 188,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.advocacyads.com/*" }
        },
        {
            id: trackerUrls.length + 189,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.outdoorads.com/*" }
        },
        {
            id: trackerUrls.length + 190,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inhouseads.com/*" }
        },
        {
            id: trackerUrls.length + 191,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pureads.com/*" }
        },
        {
            id: trackerUrls.length + 192,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.stickerads.com/*" }
        },
        {
            id: trackerUrls.length + 193,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.emailads.com/*" }
        },
        {
            id: trackerUrls.length + 194,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.connectads.com/*" }
        },
        {
            id: trackerUrls.length + 195,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.collaborateads.com/*" }
        },
        {
            id: trackerUrls.length + 196,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.groupads.com/*" }
        },
        {
            id: trackerUrls.length + 197,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.specialofferads.com/*" }
        },
        {
            id: trackerUrls.length + 198,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.classyads.com/*" }
        },
        {
            id: trackerUrls.length + 199,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.virtualads.com/*" }
        },
        {
            id: trackerUrls.length + 200,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.teamads.com/*" }
        },
        {
            id: trackerUrls.length + 201,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.rockstarads.com/*" }
        },
        {
            id: trackerUrls.length + 202,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.summitads.com/*" }
        },
        {
            id: trackerUrls.length + 203,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.successads.com/*" }
        },
        {
            id: trackerUrls.length + 204,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.oneclickads.com/*" }
        },
        {
            id: trackerUrls.length + 205,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.myfreelanceads.com/*" }
        },
        {
            id: trackerUrls.length + 206,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adstrategy.com/*" }
        },
        {
            id: trackerUrls.length + 207,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.webtrafficgenerators.com/*" }
        },
        {
            id: trackerUrls.length + 208,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adgains.com/*" }
        },
        {
            id: trackerUrls.length + 209,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trafficmasterads.com/*" }
        },
        {
            id: trackerUrls.length + 210,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.specialtyads.com/*" }
        },
        {
            id: trackerUrls.length + 211,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.realads.com/*" }
        },
        {
            id: trackerUrls.length + 212,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.elegantads.com/*" }
        },
        {
            id: trackerUrls.length + 213,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.friendads.com/*" }
        },
        {
            id: trackerUrls.length + 214,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.exploreads.com/*" }
        },
        {
            id: trackerUrls.length + 215,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.conversationalads.com/*" }
        },
        {
            id: trackerUrls.length + 216,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.highlightedads.com/*" }
        },
        {
            id: trackerUrls.length + 217,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.engagingads.com/*" }
        },
        {
            id: trackerUrls.length + 218,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.approachads.com/*" }
        },
        {
            id: trackerUrls.length + 219,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trendingads.com/*" }
        },
        {
            id: trackerUrls.length + 220,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.monetizationads.com/*" }
        },
        {
            id: trackerUrls.length + 221,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.charmingads.com/*" }
        },
        {
            id: trackerUrls.length + 222,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trendsettingads.com/*" }
        },
        {
            id: trackerUrls.length + 223,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.targetedads.com/*" }
        },
        {
            id: trackerUrls.length + 224,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.growingads.com/*" }
        },
        {
            id: trackerUrls.length + 225,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.transitionads.com/*" }
        },
        {
            id: trackerUrls.length + 226,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.drivingads.com/*" }
        },
        {
            id: trackerUrls.length + 227,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.affectingads.com/*" }
        },
        {
            id: trackerUrls.length + 228,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.integratedads.com/*" }
        },
        {
            id: trackerUrls.length + 229,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.togetherads.com/*" }
        },
        {
            id: trackerUrls.length + 230,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.expressads.com/*" }
        },
        {
            id: trackerUrls.length + 231,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.unmatchedads.com/*" }
        },
        {
            id: trackerUrls.length + 232,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.youngads.com/*" }
        },
        {
            id: trackerUrls.length + 233,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.enthusiasticads.com/*" }
        },
        {
            id: trackerUrls.length + 234,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.exceedingads.com/*" }
        },
        {
            id: trackerUrls.length + 235,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fineads.com/*" }
        },
        {
            id: trackerUrls.length + 236,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.abundantads.com/*" }
        },
        {
            id: trackerUrls.length + 237,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.rightads.com/*" }
        },
        {
            id: trackerUrls.length + 238,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.exponentialads.com/*" }
        },
        {
            id: trackerUrls.length + 239,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.curatedads.com/*" }
        },
        {
            id: trackerUrls.length + 240,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.limitlessads.com/*" }
        },
        {
            id: trackerUrls.length + 241,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.informedads.com/*" }
        },
        {
            id: trackerUrls.length + 242,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.contextualads.com/*" }
        },
        {
            id: trackerUrls.length + 243,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.organicads.com/*" }
        },
        {
            id: trackerUrls.length + 244,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.futuristicads.com/*" }
        },
        {
            id: trackerUrls.length + 245,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.historicalads.com/*" }
        },
        {
            id: trackerUrls.length + 246,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.uniquelyads.com/*" }
        },
        {
            id: trackerUrls.length + 247,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.classicalads.com/*" }
        },
        {
            id: trackerUrls.length + 248,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.allianceads.com/*" }
        },
        {
            id: trackerUrls.length + 249,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.commercialads.com/*" }
        },
        {
            id: trackerUrls.length + 250,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.covertads.com/*" }
        },
        {
            id: trackerUrls.length + 251,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.instantads.com/*" }
        },
        {
            id: trackerUrls.length + 252,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.successstoryads.com/*" }
        },
        {
            id: trackerUrls.length + 253,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.rewardingads.com/*" }
        },
        {
            id: trackerUrls.length + 254,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.cleverads.com/*" }
        },
        {
            id: trackerUrls.length + 255,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pioneeringads.com/*" }
        },
        {
            id: trackerUrls.length + 256,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.collectiveads.com/*" }
        },
        {
            id: trackerUrls.length + 257,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inventiveads.com/*" }
        },
        {
            id: trackerUrls.length + 258,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.thrivingads.com/*" }
        },
        {
            id: trackerUrls.length + 259,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.innovationads.com/*" }
        },
        {
            id: trackerUrls.length + 260,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.advocateads.com/*" }
        },
        {
            id: trackerUrls.length + 261,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.impactads.com/*" }
        },
        {
            id: trackerUrls.length + 262,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.catalystads.com/*" }
        },
        {
            id: trackerUrls.length + 263,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.meticulousads.com/*" }
        },
        {
            id: trackerUrls.length + 264,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.brightfutureads.com/*" }
        },
        {
            id: trackerUrls.length + 265,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.globalads.com/*" }
        },
        {
            id: trackerUrls.length + 266,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.supremeads.com/*" }
        },
        {
            id: trackerUrls.length + 267,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.maximumads.com/*" }
        },
        {
            id: trackerUrls.length + 268,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.openfieldads.com/*" }
        },
        {
            id: trackerUrls.length + 269,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.foresightedads.com/*" }
        },
        {
            id: trackerUrls.length + 270,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.refinedads.com/*" }
        },
        {
            id: trackerUrls.length + 271,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.characteristicads.com/*" }
        },
        {
            id: trackerUrls.length + 272,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adroitads.com/*" }
        },
        {
            id: trackerUrls.length + 273,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.ultimateads.com/*" }
        },
        {
            id: trackerUrls.length + 274,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.strategicads.com/*" }
        },
        {
            id: trackerUrls.length + 275,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.prominentads.com/*" }
        },
        {
            id: trackerUrls.length + 276,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.opulentads.com/*" }
        },
        {
            id: trackerUrls.length + 277,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.genuineads.com/*" }
        },
        {
            id: trackerUrls.length + 278,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.revealingads.com/*" }
        },
        {
            id: trackerUrls.length + 279,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.modernads.com/*" }
        },
        {
            id: trackerUrls.length + 280,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.heightsads.com/*" }
        },
        {
            id: trackerUrls.length + 281,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.championads.com/*" }
        },
        {
            id: trackerUrls.length + 282,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.beneficialads.com/*" }
        },
        {
            id: trackerUrls.length + 283,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.honestads.com/*" }
        },
        {
            id: trackerUrls.length + 284,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.healthyads.com/*" }
        },
        {
            id: trackerUrls.length + 285,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.spectacularads.com/*" }
        },
        {
            id: trackerUrls.length + 286,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.dedicatedads.com/*" }
        },
        {
            id: trackerUrls.length + 287,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.thrivingcommunityads.com/*" }
        },
        {
            id: trackerUrls.length + 288,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.influentialads.com/*" }
        },
        {
            id: trackerUrls.length + 289,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.enlighteningads.com/*" }
        },
        {
            id: trackerUrls.length + 290,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.soundads.com/*" }
        },
        {
            id: trackerUrls.length + 291,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.nurturingads.com/*" }
        },
        {
            id: trackerUrls.length + 292,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.constructiveads.com/*" }
        },
        {
            id: trackerUrls.length + 293,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.elevatedads.com/*" }
        },
        {
            id: trackerUrls.length + 294,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.well-roundedads.com/*" }
        },
        {
            id: trackerUrls.length + 295,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.reliableads.com/*" }
        },
        {
            id: trackerUrls.length + 296,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.lastingads.com/*" }
        },
        {
            id: trackerUrls.length + 297,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.elevatingads.com/*" }
        },
        {
            id: trackerUrls.length + 298,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.inspiringads.com/*" }
        },
        {
            id: trackerUrls.length + 299,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.verifiableads.com/*" }
        },
        {
            id: trackerUrls.length + 300,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.standoutads.com/*" }
        },
        {
            id: trackerUrls.length + 301,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.specializedads.com/*" }
        },
        {
            id: trackerUrls.length + 302,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.gatheredads.com/*" }
        },
        {
            id: trackerUrls.length + 303,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bloomingads.com/*" }
        },
        {
            id: trackerUrls.length + 304,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.culturedads.com/*" }
        },
        {
            id: trackerUrls.length + 305,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.adaptedads.com/*" }
        },
        {
            id: trackerUrls.length + 306,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.filteredads.com/*" }
        },
        {
            id: trackerUrls.length + 307,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.result-drivenads.com/*" }
        },
        {
            id: trackerUrls.length + 308,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.valuedads.com/*" }
        },
        {
            id: trackerUrls.length + 309,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.elevatedthinkingads.com/*" }
        },
        {
            id: trackerUrls.length + 310,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.originalads.com/*" }
        },
        {
            id: trackerUrls.length + 311,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.steadyads.com/*" }
        },
        {
            id: trackerUrls.length + 312,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.informedchoiceads.com/*" }
        },
        {
            id: trackerUrls.length + 313,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.fruitfulads.com/*" }
        },
        {
            id: trackerUrls.length + 314,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.lifelineads.com/*" }
        },
        {
            id: trackerUrls.length + 315,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.thrivingbusinessads.com/*" }
        },
        {
            id: trackerUrls.length + 316,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.indispensableads.com/*" }
        },
        {
            id: trackerUrls.length + 317,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.expandingads.com/*" }
        },
        {
            id: trackerUrls.length + 318,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.evergreenthinkingads.com/*" }
        },
        {
            id: trackerUrls.length + 319,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.lifetimeads.com/*" }
        },
        {
            id: trackerUrls.length + 320,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.significantads.com/*" }
        },
        {
            id: trackerUrls.length + 321,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.impactfulads.com/*" }
        },
        {
            id: trackerUrls.length + 322,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pivotalads.com/*" }
        },
        {
            id: trackerUrls.length + 323,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.welcomingads.com/*" }
        },
        {
            id: trackerUrls.length + 324,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.transformingads.com/*" }
        },
        {
            id: trackerUrls.length + 325,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.trendleadingads.com/*" }
        },
        {
            id: trackerUrls.length + 326,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.invitingads.com/*" }
        },
        {
            id: trackerUrls.length + 327,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.doubleclick.net/*" }
        },


        {
            id: trackerUrls.length + 328,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.bannerads.net/*" }
        },
        // Page Push Ads
        {
            id: trackerUrls.length + 329,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pushadnetwork.com/*" }
        },
        // Push Notifications
        {
            id: trackerUrls.length + 330,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.pushnotifications.com/*" }
        },
        // Interstitial Ads
        {
            id: trackerUrls.length + 331,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*.interstitials.com/*" }
        },
        // Block unwanted redirections
        {
            id: trackerUrls.length + 332,
            priority: 1,
            action: { type: "block" },
            condition: { urlFilter: "*://*/*?redirect=*" } // Example pattern for redirections
        },

    ];

    // Update blocking rules
    chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [...rules, ...additionalBlockRules],
        removeRuleIds: [...rules.map(rule => rule.id), ...additionalBlockRules.map(rule => rule.id)]
    }, () => {
        console.log("Blocking rules for all ad types, pop-ups, and unwanted redirects enabled.");
    });
}

// Enable blocking rules on installation
chrome.runtime.onInstalled.addListener(() => {
    setupBlockingRules();
    chrome.storage.sync.set({ isBlocking: true }); // Default to enabled
});

// Toggle blocking on user request
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        chrome.storage.sync.get('isBlocking', (data) => {
            const isBlocking = !data.isBlocking;
            chrome.storage.sync.set({ isBlocking });

            if (isBlocking) {
                setupBlockingRules();
                console.log("Blocking enabled.");
            } else {
                // Remove all blocking rules if disabled
                const allRuleIds = [...Array(trackerUrls.length + 15).keys()].map(i => i + 1);
                chrome.declarativeNetRequest.updateDynamicRules({
                    removeRuleIds: allRuleIds
                }, () => {
                    console.log("Blocking disabled.");
                });
            }
            sendResponse({ success: true });
        });
    }
    return true; // Keep the message channel open for sendResponse
});
