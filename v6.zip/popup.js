document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('toggle');
    const adsBlocked = document.getElementById('adsBlocked');
    const allowlistInput = document.getElementById('allowlistInput');
    const addAllowlist = document.getElementById('addAllowlist');
    const allowlist = document.getElementById('allowlist');

    // Load initial state
    chrome.storage.sync.get(['isBlocking', 'allowlistedSites'], (data) => {
        toggle.checked = data.isBlocking !== false;
        renderAllowlist(data.allowlistedSites || []);
    });

    chrome.storage.local.get('adBlockCount', (data) => {
        adsBlocked.innerText = data.adBlockCount || 0;
    });

    function reloadActiveTab() {
        try {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
            });
        } catch (e) { /* ignore in restricted contexts */ }
    }

    // Toggle blocking
    toggle.addEventListener('change', () => {
        const isBlocking = toggle.checked;
        chrome.storage.sync.set({ isBlocking });
        chrome.runtime.sendMessage({ action: 'toggleBlocking', isBlocking }, () => {
            reloadActiveTab();
        });
    });

    // Add to allowlist
    addAllowlist.addEventListener('click', () => {
        const site = allowlistInput.value.trim();
        if (site) {
            chrome.storage.sync.get('allowlistedSites', (data) => {
                const sites = data.allowlistedSites || [];
                if (!sites.includes(site)) {
                    sites.push(site);
                    chrome.storage.sync.set({ allowlistedSites: sites }, () => {
                        renderAllowlist(sites);
                        allowlistInput.value = '';
                        reloadActiveTab();
                    });
                }
            });
        }
    });

    // Render allowlist
    function renderAllowlist(sites) {
        allowlist.innerHTML = '';
        sites.forEach((site, index) => {
            const li = document.createElement('li');
            li.className = 'flex items-center justify-between bg-gray-100 p-2 rounded-lg';
            li.innerHTML = `
                <span class="flex-1">${site}</span>
                <div class="flex-shrink-0">
                    <button data-index="${index}" class="edit-btn text-blue-600 hover:underline mr-2">Edit</button>
                    <button data-index="${index}" class="delete-btn text-red-600 hover:underline">Delete</button>
                </div>
            `;
            allowlist.appendChild(li);
        });
    }

    // Handle allowlist actions (edit/delete)
    allowlist.addEventListener('click', (e) => {
        const index = e.target.dataset.index;
        if (e.target.classList.contains('delete-btn')) {
            chrome.storage.sync.get('allowlistedSites', (data) => {
                const sites = data.allowlistedSites || [];
                sites.splice(index, 1);
                chrome.storage.sync.set({ allowlistedSites: sites }, () => {
                    renderAllowlist(sites);
                    reloadActiveTab();
                });
            });
        }

        if (e.target.classList.contains('edit-btn')) {
            const li = e.target.closest('li');
            const span = li.querySelector('span');
            const originalSite = span.textContent;
            span.innerHTML = `<input type="text" value="${originalSite}" class="w-full px-1 border rounded">`;
            e.target.textContent = 'Save';
            e.target.classList.remove('edit-btn');
            e.target.classList.add('save-btn');
        }

        if (e.target.classList.contains('save-btn')) {
            const li = e.target.closest('li');
            const input = li.querySelector('input');
            const newSite = input.value.trim();
            if (newSite) {
                chrome.storage.sync.get('allowlistedSites', (data) => {
                    const sites = data.allowlistedSites || [];
                    sites[index] = newSite;
                    chrome.storage.sync.set({ allowlistedSites: sites }, () => {
                        renderAllowlist(sites);
                        reloadActiveTab();
                    });
                });
            }
        }
    });

    // Update ad count from storage changes
    chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'local' && changes.adBlockCount) {
            adsBlocked.innerText = changes.adBlockCount.newValue || 0;
        }
        if (namespace === 'sync' && changes.allowlistedSites) {
            renderAllowlist(changes.allowlistedSites.newValue || []);
        }
    });
});
