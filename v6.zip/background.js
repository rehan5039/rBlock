// Anti-detection script to be injected into pages
const antiDetectionScript = {
    id: 'anti-adblock-detector',
    matches: ['<all_urls>'],
    world: 'MAIN',
    runAt: 'document_start',
    js: [`
        (function() {
            // Override property getters that are commonly used to detect ad blockers
            const propertiesToDefend = [
                'googletagmanager',
                'ga',
                'googletag',
                'google_ad_client',
                'google_ad_slot',
                'adsbygoogle',
                'isAdBlockActive',
                'showAds',
                'canRunAds',
                'isAdBlockEnabled'
            ];

            // Create fake ad elements to fool detectors
            const fakeAd = document.createElement('div');
            fakeAd.id = 'banner_ad';
            fakeAd.style.display = 'none';
            document.documentElement.appendChild(fakeAd);

            // Override common ad blocker detection methods
            window.canRunAds = true;
            window.showAds = true;
            window.adsbygoogle = { loaded: true };
            window.google_ad_status = 1;

            // Prevent detection of hidden ads
            Object.defineProperty(window, 'showAds', {
                get: function() { return true; },
                set: function() { return true; }
            });

            // Override getComputedStyle to hide ad blocking
            const originalGetComputedStyle = window.getComputedStyle;
            window.getComputedStyle = function(el) {
                const style = originalGetComputedStyle(el);
                if (el.id === 'banner_ad') {
                    return new Proxy(style, {
                        get: function(target, prop) {
                            if (prop === 'display') return 'block';
                            if (prop === 'visibility') return 'visible';
                            if (prop === 'height') return '10px';
                            return target[prop];
                        }
                    });
                }
                return style;
            };

            // Intercept and block known ad blocker detection scripts
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.tagName === 'SCRIPT') {
                            if (node.src && (
                                node.src.includes('adblock') ||
                                node.src.includes('blockadblock') ||
                                node.src.includes('anti-adblock') ||
                                node.src.includes('ads.js')
                            )) {
                                node.remove();
                            }
                        }
                    });
                });
            });

            observer.observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        })();
    `]
};

// Define tracker URLs to be blocked
const trackerUrls = [
    "*://*.googlesyndication.com/*",
    "*://*.facebook.com/*",
    "*://*.tracking.com/*",
    "*://*.analytics.google.com/*",
    "*://*.adsterra.com/*",
    "*://*.adclick.g.doubleclick.net/*",
    "*://*.adserver.adtech.de/*",
    "*://*.cdn.adform.net/*",
    "*://*.adready.com/*",
    "*://*.advertising.aol.com/*",
    "*://*.media.net/*"
];

// Helper: build rules with allowlist exclusions
function buildRules(allowlistedSites = []) {
    return trackerUrls.map((url, index) => ({
        id: index + 1,
        priority: 1,
        action: { type: "block" },
        condition: {
            urlFilter: url,
            excludedDomains: allowlistedSites
        }
    }));
}

function ruleIds() {
    return trackerUrls.map((_, i) => i + 1);
}

// High-priority allow rules to override any block (static or dynamic)
function buildAllowRules(allowlistedSites = []) {
    return (allowlistedSites || []).map((domain, i) => ({
        id: 10000 + i + 1,
        priority: 1000,
        action: { type: "allow" },
        condition: {
            domains: [domain]
        }
    }));
}

function allowRuleIds(allowlistedSites = []) {
    // use same count as sites to compute ids
    return (allowlistedSites || []).map((_, i) => 10000 + i + 1);
}

// Function to enable blocking and anti-detection
function enableBlocking() {
    chrome.storage.sync.get('allowlistedSites', (data) => {
        const allowlistedSites = data.allowlistedSites || [];

        const add = [...buildRules(allowlistedSites), ...buildAllowRules(allowlistedSites)];

        // Clear any existing dynamic rules first
        chrome.declarativeNetRequest.getDynamicRules((existing) => {
            const allIds = existing.map(r => r.id);
            chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: allIds, addRules: add }, () => {
                if (chrome.runtime.lastError) {
                    console.error('updateDynamicRules error (enable):', chrome.runtime.lastError.message);
                } else {
                    console.log("Blocking rules enabled (dynamic + allow overrides).");
                }
            });
        });

        // Ensure static ruleset is enabled as well
        chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ['ruleset_1'] }, () => {
            if (chrome.runtime.lastError) {
                console.error('updateEnabledRulesets enable error:', chrome.runtime.lastError.message);
            }
        });

        // Register anti-detection script
        chrome.scripting.registerContentScripts([antiDetectionScript])
            .catch(err => console.log('Anti-detection script error:', err));
    });
}

// Function to disable blocking
function disableBlocking() {
    // Remove all dynamic rules (both block and allow)
    chrome.declarativeNetRequest.getDynamicRules((existing) => {
        const allIds = existing.map(r => r.id);
        chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: allIds }, () => {
            if (chrome.runtime.lastError) {
                console.error('updateDynamicRules error (disable):', chrome.runtime.lastError.message);
            } else {
                console.log("Dynamic rules cleared.");
            }
        });
    });

    // Disable the static ruleset
    chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ['ruleset_1'] }, () => {
        if (chrome.runtime.lastError) {
            console.error('updateEnabledRulesets disable error:', chrome.runtime.lastError.message);
        }
    });

    // Remove anti-detection script
    chrome.scripting.unregisterContentScripts({ ids: [antiDetectionScript.id] });
}

let adBlockCount = 0;

// Initial setup: enable blocking on installation
chrome.runtime.onInstalled.addListener(() => {
    enableBlocking();
    chrome.storage.sync.set({ isBlocking: true });
    chrome.storage.local.set({ adBlockCount: 0 }); // Initialize count
});

// Listen for blocked requests and update the count
chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
        if (details.error === 'net::ERR_BLOCKED_BY_CLIENT') {
            chrome.storage.sync.get(['isBlocking', 'allowlistedSites'], (cfg) => {
                if (cfg.isBlocking === false) return;
                try {
                    const url = new URL(details.url);
                    const allow = (cfg.allowlistedSites || []).some(site => url.hostname.includes(site));
                    if (allow) return;
                } catch (e) {}
                chrome.storage.local.get('adBlockCount', (data) => {
                    const count = (data.adBlockCount || 0) + 1;
                    chrome.storage.local.set({ adBlockCount: count });
                });
            });
        }
    },
    { urls: ['<all_urls>'] }
);

// Listener to receive toggle requests from popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        chrome.storage.sync.set({ isBlocking: request.isBlocking });
        if (request.isBlocking) {
            enableBlocking();
        } else {
            disableBlocking();
        }
        sendResponse({ success: true });
    }
});

// Re-apply rules when allowlist changes (while blocking is enabled)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.allowlistedSites) {
        chrome.storage.sync.get('isBlocking', (d) => {
            if (d.isBlocking === false) return;
            const allowlistedSites = changes.allowlistedSites.newValue || [];
            const add = [...buildRules(allowlistedSites), ...buildAllowRules(allowlistedSites)];
            // Remove everything first for simplicity
            chrome.declarativeNetRequest.getDynamicRules((existing) => {
                const allIds = existing.map(r => r.id);
                chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: allIds, addRules: add });
            });
        });
    }
});
