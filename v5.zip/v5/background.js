// Anti-detection script to be injected into pages
const antiDetectionScript = {
    id: 'anti-adblock-detector',
    matches: ['<all_urls>'],
    world: 'MAIN',
    runAt: 'document_start',
    js: [`
        (function() {
            // Override property getters that are commonly used to detect ad blockers
            const propertiesToDefend = [
                'googletagmanager',
                'ga',
                'googletag',
                'google_ad_client',
                'google_ad_slot',
                'adsbygoogle',
                'isAdBlockActive',
                'showAds',
                'canRunAds',
                'isAdBlockEnabled'
            ];

            // Create fake ad elements to fool detectors
            const fakeAd = document.createElement('div');
            fakeAd.id = 'banner_ad';
            fakeAd.style.display = 'none';
            document.documentElement.appendChild(fakeAd);

            // Override common ad blocker detection methods
            window.canRunAds = true;
            window.showAds = true;
            window.adsbygoogle = { loaded: true };
            window.google_ad_status = 1;

            // Prevent detection of hidden ads
            Object.defineProperty(window, 'showAds', {
                get: function() { return true; },
                set: function() { return true; }
            });

            // Override getComputedStyle to hide ad blocking
            const originalGetComputedStyle = window.getComputedStyle;
            window.getComputedStyle = function(el) {
                const style = originalGetComputedStyle(el);
                if (el.id === 'banner_ad') {
                    return new Proxy(style, {
                        get: function(target, prop) {
                            if (prop === 'display') return 'block';
                            if (prop === 'visibility') return 'visible';
                            if (prop === 'height') return '10px';
                            return target[prop];
                        }
                    });
                }
                return style;
            };

            // Intercept and block known ad blocker detection scripts
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.tagName === 'SCRIPT') {
                            if (node.src && (
                                node.src.includes('adblock') ||
                                node.src.includes('blockadblock') ||
                                node.src.includes('anti-adblock') ||
                                node.src.includes('ads.js')
                            )) {
                                node.remove();
                            }
                        }
                    });
                });
            });

            observer.observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        })();
    `]
};

// Define tracker URLs to be blocked
const trackerUrls = [
    "*://*.googlesyndication.com/*",
    "*://*.facebook.com/*",
    "*://*.tracking.com/*",
    "*://*.analytics.google.com/*",
    "*://*.adsterra.com/*",
    "*://*.adclick.g.doubleclick.net/*",
    "*://*.adserver.adtech.de/*",
    "*://*.cdn.adform.net/*",
    "*://*.adready.com/*",
    "*://*.advertising.aol.com/*",
    "*://*.media.net/*"
];

// Convert URLs to rule format for declarativeNetRequest
const rules = trackerUrls.map((url, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "block" },
    condition: { urlFilter: url }
}));

// Function to enable blocking and anti-detection
function enableBlocking() {
    // Update blocking rules
    chrome.declarativeNetRequest.updateDynamicRules({
        addRules: rules,
        removeRuleIds: rules.map(rule => rule.id)
    }, () => {
        console.log("Blocking rules enabled.");
    });

    // Register anti-detection script
    chrome.scripting.registerContentScripts([antiDetectionScript])
        .catch(err => console.log('Anti-detection script error:', err));
}

// Function to disable blocking
function disableBlocking() {
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: rules.map(rule => rule.id)
    }, () => {
        console.log("Blocking rules disabled.");
    });

    // Remove anti-detection script
    chrome.scripting.unregisterContentScripts({
        ids: [antiDetectionScript.id]
    });
}

// Initial setup: enable blocking on installation
chrome.runtime.onInstalled.addListener(() => {
    enableBlocking();
    chrome.storage.sync.set({ isBlocking: true });
});

// Listener to receive toggle requests from popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleBlocking') {
        if (request.isBlocking) {
            enableBlocking();
        } else {
            disableBlocking();
        }
        chrome.storage.sync.set({ isBlocking: request.isBlocking });
        sendResponse({ success: true });
    }
});
